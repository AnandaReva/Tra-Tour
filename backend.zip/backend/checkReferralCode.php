<?php

// Fungsi untuk memeriksa validitas API key
function is_valid_api_key($api_key)
{
    // Ganti dengan logika validasi sesuai kebutuhan Anda
    return $api_key === 'akascabul';
}

// Menerima data referral_code dari body permintaan POST
$referral_code = $_POST['referral_code'];

// Mendapatkan API key dari header permintaan
$api_key = $_SERVER['HTTP_API_KEY'];

$response = array();

// Memeriksa validitas API key
if (!is_valid_api_key($api_key)) {
    $response['success'] = false;
    $response['message'] = "Invalid API Key";
    echo json_encode($response);
    exit; // Menghentikan eksekusi script
}

// Koneksi ke database
$servername = "localhost";
$username = "id21953977_anandareva";
$password = "Empatlimaenam456";
$database = "id21953977_tratour";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $database);

// Mengecek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Membuat query untuk mencari referral_code pada tabel user
$sql = "SELECT * FROM user WHERE referral_code = '$referral_code'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Mendapatkan hasil query dalam bentuk array asosiatif
    $data = $result->fetch_assoc();

    // Menyimpan data dalam array response
    $response['success'] = true;
    $response['message'] = "Referral code ditemukan";
    $response['data'] = $data;
} else {
    // Jika referral_code tidak ditemukan
    $response['success'] = false;
    $response['message'] = "Referral code tidak ditemukan";
}

// Mengirim respons dalam format JSON
header('Content-Type: application/json');
echo json_encode($response);

// Menutup koneksi database
$conn->close();
