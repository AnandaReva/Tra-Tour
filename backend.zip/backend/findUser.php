<?php

// Fungsi untuk memeriksa validitas API key
function is_valid_api_key($api_key) {
    // Ganti dengan logika validasi sesuai kebutuhan Anda
    return $api_key === 'akascabul';
}

// Menerima data dari body permintaan POST
$email = $_POST['email'];

// Mendapatkan API key dari header permintaan
$api_key = $_SERVER['HTTP_API_KEY'];

$response = array();

// Memeriksa validitas API key
if (!is_valid_api_key($api_key)) {
    $response['success'] = false;
    $response['message'] = "Invalid API Key";
    echo json_encode($response);
    exit; // Menghentikan eksekusi script
}

// Koneksi ke database
$servername = "localhost";
$username = "id21953977_anandareva";
$password = "Empatlimaenam456";
$database = "id21953977_tratour";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $database);

// Mengecek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Membuat query untuk mengambil data user berdasarkan email
$sql = "SELECT * FROM user WHERE email = '$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Mendapatkan hasil query dalam bentuk array asosiatif
    $data = $result->fetch_assoc();

    // Menyimpan data dalam array response
    $response['success'] = true;
    $response['message'] = "Data ditemukan";
    $response['data'] = $data;
} else {
    // Jika tidak ada data yang ditemukan
    $response['success'] = false;
    $response['message'] = "Data tidak ditemukan";
}

// Mengirim respons dalam format JSON
header('Content-Type: application/json');
echo json_encode($response);

// Menutup koneksi database
$conn->close();

?>
