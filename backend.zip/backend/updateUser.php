<?php

// Fungsi untuk memeriksa validitas API key
function is_valid_api_key($api_key)
{
    // Ganti dengan logika validasi sesuai kebutuhan Anda
    return $api_key === 'akascabul';
}

// Menerima data dari body permintaan POST
$username = $_POST['username'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];
$user_point = $_POST['user_point'];
$user_type = $_POST['user_type'];
$profile_image = $_POST['profile_image'];
$referral_code = $_POST['referral_code'];
$created_at = $_POST['created_at'];
$updated_at = $_POST['updated_at'];

// Mendapatkan API key dari header permintaan
$api_key = $_SERVER['HTTP_API_KEY'];

$response = array();

// Memeriksa validitas API key
if (!is_valid_api_key($api_key)) {
    $response['success'] = false;
    $response['message'] = "Invalid API Key";
    echo json_encode($response);
    exit; // Menghentikan eksekusi script
}

// Koneksi ke database
$servername = "localhost";
$db_username = "root";
$db_password = "password";
$database = "sampah";

// Membuat koneksi
$conn = new mysqli($servername, $db_username, $db_password, $database);

// Mengecek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Membuat query untuk memeriksa apakah user sudah ada di database berdasarkan email
$sql_check_user = "SELECT * FROM user WHERE email = '$email'";
$result_check_user = $conn->query($sql_check_user);

if ($result_check_user->num_rows > 0) {
    // Jika user sudah ada, maka lakukan update data
    $sql_update_user = "UPDATE user 
                        SET username='$username', 
                            no_hp='$phone', 
                            password='$password', 
                            user_point='$user_point', 
                            user_type='$user_type', 
                            profile_image='$profile_image', 
                            referral_code='$referral_code', 
                            updated_at='$updated_at' 
                        WHERE email='$email'";

    if ($conn->query($sql_update_user) === TRUE) {
        // Jika data berhasil diupdate
        $response['success'] = true;
        $response['message'] = "Data user berhasil diupdate";
    } else {
        // Jika terjadi kesalahan saat mengupdate data
        $response['success'] = false;
        $response['message'] = "Error: " . $sql_update_user . "<br>" . $conn->error;
    }
} else {
    // Jika user belum ada, tampilkan pesan error
    $response['success'] = false;
    $response['message'] = "User dengan email '$email' tidak ditemukan";
}

// Mengirim respons dalam format JSON
header('Content-Type: application/json');
echo json_encode($response);

// Menutup koneksi database
$conn->close();
